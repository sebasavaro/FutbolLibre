/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trophy, Volume2, VolumeX } from 'lucide-react';

// Configuration - Football Theme
const CONFIG = {
  // Stadium image
  imageUrl: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=1920&auto=format&fit=crop",
  // Crowd noise or stadium ambiance (example URL)
  audioUrl: "https://www.soundjay.com/misc/sounds/stadium-crowd-1.mp3",
  title: "FÚTBOL EN VIVO",
  buttonText: "VER PARTIDOS"
};

export default function App() {
  const [hasStarted, setHasStarted] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const handleStart = () => {
    setHasStarted(true);
    if (audioRef.current) {
      audioRef.current.play().catch(err => console.error("Audio playback failed:", err));
    }
  };

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  return (
    <div className="relative w-full h-screen bg-neutral-950 flex items-center justify-center font-sans overflow-hidden">
      {/* Background Audio */}
      <audio
        ref={audioRef}
        src={CONFIG.audioUrl}
        loop
      />

      <AnimatePresence mode="wait">
        {!hasStarted ? (
          <motion.div
            key="start-screen"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="z-20 flex flex-col items-center gap-8 px-4 text-center"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="mb-4"
            >
              <Trophy className="w-16 h-16 text-emerald-500 mb-4 mx-auto" />
              <h1 className="text-5xl md:text-7xl font-black tracking-tighter text-white uppercase italic">
                {CONFIG.title}
              </h1>
            </motion.div>
            
            <motion.button
              whileHover={{ scale: 1.05, backgroundColor: "rgb(16 185 129)" }}
              whileTap={{ scale: 0.95 }}
              onClick={handleStart}
              className="px-12 py-5 bg-emerald-600 text-white font-bold text-xl rounded-full shadow-[0_0_30px_rgba(16,185,129,0.3)] transition-all uppercase tracking-widest"
            >
              {CONFIG.buttonText}
            </motion.button>
          </motion.div>
        ) : (
          <motion.div
            key="main-content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.5 }}
            className="relative w-full h-full"
          >
            {/* The Football Stadium Image */}
            <motion.img
              initial={{ scale: 1.05 }}
              animate={{ scale: 1 }}
              transition={{ duration: 20, ease: "linear" }}
              src={CONFIG.imageUrl}
              alt="Stadium"
              className="absolute inset-0 w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />

            {/* Dark gradient overlay for a cinematic feel */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 pointer-events-none" />

            {/* Mute Control */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="absolute bottom-8 right-8 z-30"
            >
              <button
                onClick={toggleMute}
                className="p-4 rounded-full bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20 transition-all"
              >
                {isMuted ? (
                  <VolumeX className="w-6 h-6 text-white" />
                ) : (
                  <Volume2 className="w-6 h-6 text-white" />
                )}
              </button>
            </motion.div>

            {/* Subtle Title Overlay */}
            <div className="absolute top-8 left-8 z-30">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-600 rounded-full animate-pulse" />
                <span className="text-white font-bold tracking-widest text-sm uppercase">EN VIVO</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Background decoration for start screen */}
      {!hasStarted && (
        <div className="absolute inset-0 z-0 opacity-20">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-emerald-900/40 via-transparent to-transparent" />
        </div>
      )}
    </div>
  );
}
